# Minetest 5.0+ mod: cake
Adds delicious cakes to Minetest!

## License
Copyright (c) 2015 MrIbby <siribby@outlook.com>
- Code in licensed under the MIT license, see [LICENSE](LICENSE) for details.

### Authors and licenses of textures
- TenPlus1 (WTFPL):
    - `cake.png`
    - `cake_bottom.png`, derivative
    - `cake_inner.png`, derivative
    - `cake_side.png`, derivative
    - `cake_sugar.png`
    - `cake_top.png`, derivative
