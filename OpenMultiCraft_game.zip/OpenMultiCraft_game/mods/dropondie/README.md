Minetest DroponDie Mod

Drops contents of inventory and crafting grid when player dies
