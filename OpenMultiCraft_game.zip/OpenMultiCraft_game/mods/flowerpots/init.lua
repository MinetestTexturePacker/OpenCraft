local path = minetest.get_modpath("flowerpots")

dofile(path.."/nodes.lua")